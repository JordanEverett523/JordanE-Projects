/**
 * 
 */
/**
 * @author jorda
 *
 */
module ClassAssignments {
	requires java.desktop;
}