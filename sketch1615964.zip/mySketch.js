var backImage;
var celljr1;
var celljr2
var celljr3
var celljr4
var celljr5
var celljr6
var celljr7
var celljr8
var celljr9
var celljr10
var gohan;
var cx = 0;
var cy = 0;
var score = 0
var timer;
var userLost = false
var userWon = false
var gameTime = 20;
var gohanwin;
var gohanlost;

function preload(){
  backImage = loadImage("kamehouse.png")
  celljr = loadImage("celljr.png")
  gohan = loadImage("gohan.png")
  gohanWin = loadImage("gohanwinner.jpg")
  gohanLost = loadImage("gohanlost.webp")
  
}

function setup() {
	createCanvas(windowWidth, windowHeight);
  timer = setInterval(handleTimer, 1000);
  celljr1 = new Enemy()
  celljr2 = new Enemy()
  celljr3 = new Enemy()
  celljr4 = new Enemy()
  celljr5 = new Enemy()
  celljr6 = new Enemy()
  celljr7 = new Enemy()
  celljr8 = new Enemy()
  celljr9 = new Enemy()
  celljr10 = new Enemy()
  
	
}

function draw() {
  background(backImage)
  celljr1.display()
  celljr2.display()
  celljr3.display()
  celljr4.display()
  celljr5.display()
  celljr6.display()
  celljr7.display()
  celljr8.display()
  celljr9.display()
  celljr10.display()
  celljr1.pop()
  celljr2.pop()
  celljr3.pop()
  celljr4.pop()
  celljr5.pop()
  celljr6.pop()
  celljr7.pop()
  celljr8.pop()
  celljr9.pop()
  celljr10.pop()

  fill(255);
  text("Score: " + score, 100, 50)
  text("Timer: " + gameTime, windowWidth-100, 50)
  // text(lives, 50, 40)
  if (userLost == true) {
    fill(255, 0, 0)
    background(gohanLost)
    textSize(50)
    text("Gohan has been defeated.", 20, 200)
  }
  if (userWon == true) {
    fill(0, 255, 0)
    // text("You Win", 200, 200)
    background(gohanWin)

  }
  character()
  
  
  
	
}

function character(){
  image(gohan, cx, cy, 225, 225)
  // imageMode(CENTER)

  if(keyCode == UP_ARROW && keyIsPressed){
    cy-=5
  }
  else if(keyCode == DOWN_ARROW && keyIsPressed){
    cy+=5
  }
  else if(keyCode == LEFT_ARROW && keyIsPressed){
    cx-=5
  }
  else if(keyCode == RIGHT_ARROW && keyIsPressed){
    cx+=5
  }
}

function handleTimer(){
  checkScore();
  if(userWon){
    gameTime = gameTime
  }else{
    gameTime-=1
  }
  if(gameTime <= 0 ){
    gameTime = 0
  }
}
function checkScore() {
  if (score == 10) {
    userWon = true;
  }
  if(gameTime <= 0){
    userLost = true;
  }
  
}

class Enemy{

  constructor(){
    this.width = 50
    this.height = 100
    this.x = random(1000)
    this.y = random(600)
  }

  display(){
    image(celljr, this.x, this.y, this.width, this.height)
  }
  pop(){
    let distance = dist(cx, cy, this.x, this.y)

    if(distance < 50){
      // this.width = 0
      // this.height = 0
      this.x=1000000000
      this.y=1000000000
      score++
      
    }
  }
}